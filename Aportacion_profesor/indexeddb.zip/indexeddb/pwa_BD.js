// https://es.javascript.info/indexeddb
var nombreBD = 'BDpwa2SI_2023';
var versionAct = 1; //0=no existe, >=1 version

function registrarUsuario(objusuario){
    let conexion = window.indexedDB || window.mozIndexedDB || window.webkitIndexedDB || window.msIndexedDB || window.shimIndexedDB;
    //segun navegador es un objeto distinto.
    let baseDatosAbierta = conexion.open(nombreBD, versionAct);  // 1 por defecto es la versión de la base de datos
    /* open tiene los eventos posibles: upgradeneeded, success y error:  */

    baseDatosAbierta.onerror = function (event) { //Error al abrir la base de datos
        console.log('Error al abrir la BD en comprobarBD. ERR-OPEN');
    }

    //cuando no existe o se cambia la version de la bd, se ejecuta antes de onsuccess
    baseDatosAbierta.onupgradeneeded = function(event) {
        let bd = event.target.result; // o let bd = baseDatosAbierta.result;
        switch(bd.version) { // segun version de la BD en el cliente
            case 0:// NO existe la BD en el cliente, CREARLA
                console.log('No exista la BD. ERR-BD-NE');
                break;
            case 1: // El cliente tiene la version 1 ¿Actualizarla?
                console.log('BD cliente version 1. BD-V1');
                break;
            default:
                console.log('BD en version: '+bd.version);
        }

        if (!bd.objectStoreNames.contains('usuarios')) { // NO exsite 'usuarios'
            console.log('creando almacen usuarios');
            //solo es posible crear objectStores dentro de una actualizacion de la BD
            osUsuarios = bd.createObjectStore('usuarios', {keyPath: 'id_Usuario', autoIncrement: false}); // crearlo
            osUsuarios.createIndex('indUsuario','id_Usuario', {unique:true});
        }else{
            console.log('Almacen usuarios ya existe');
        }
    } //fin onupgradeneeded

    //La base de datos se ha abierto correctamente (despues de pasar por onupgradeneeded)
    baseDatosAbierta.onsuccess = function (event) {
        console.log('Se ha abierto conexión a BD pwa_BD.js');

        //insertar datos del usuario en el almacen usurios
        let bd = event.target.result; //obtenemos los objetos almacenados
        let transaccionInsertar = bd.transaction(['usuarios'], 'readwrite'); //iniciar transaccion para escribir en almacen usuarios.
        // los tipos de transacción son: readwrite y readonly, en el caso de reaswrite bloque el almacen hasta que termina la transacción.
        // Las transacciones terminan solas correctamente o con error, caso en que se deshace.
        let almacen = transaccionInsertar.objectStore('usuarios');
        
        //ejemplo de recorrer los objetos de un objectStore. Usando cursor
        // let almacenCursor = almacen.openCursor();
        // almacenCursor.onsuccess= function(){
        //     console.log('cambiar registro');
        //     let cursor = almacenCursor.result;
        //     if (cursor) {
        //         console.log(cursor.value.id_Usuario+' - '+cursor.value.usuario);
        //         //almacen.delete(cursor.value.id); si queremos eliminarlos
        //         cursor.continue(); //repetir con siguiente, se ejecutará el almacenCursos.onsuccess nuevamente
        //     }else{
        //         console.log('No hay más "registros"');
        //     }
        // }
        
        let resultado = almacen.add(objusuario); // guardar el nuevo usuario, si existe, genera error

        resultado.onerror = function (e) { //daria error por clave repetida
            // let resultadoBorrar = almacen.delete(objusuario.id_Usuario); //podriamos borrarlo y luego añadirlo o...
            console.log('Clave repetida, actualizar usuario');
            let resultado = almacen.put(objusuario); //actualizarUsuarioBD: put reemplaza el valor si ya existe.
        };

        resultado.onsuccess = function (e){
            console.log('onsuccess insertado usuario');
        }

        transaccionInsertar.oncomplete = function (e) {
            console.log('Insertado usuario'); //sin repetir.
        };
    }    

} //fin comprobarBD