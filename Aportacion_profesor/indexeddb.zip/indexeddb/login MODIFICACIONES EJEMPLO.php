<?php session_start();
    //variables que se espera recibir en $_POST
    $usuario='';
    $pass='';
    extract($_POST);
    $msj='';
    /*
    * Si validadmos por php, enviando por POST a esta misma pagina:
    */
    if($usuario!='' && $pass!=''){
        // if( $usuario=='javier' && $_POST['pass']=='123'){
        //     $_SESSION['usuario']=$usuario;
        //     header('Location: index.php');
        // }else{
        //     $msj= 'Datos erroneos.';
        // }
        require_once 'controladores/C_Usuarios.php';
        $objC_Usuarios = new C_Usuarios();
        $resultado=$objC_Usuarios->loginUsuario(array('login'=>$usuario, 'pass'=>$pass));
        if( $resultado['permitido']=='S'){
            $_SESSION['usuario']=$resultado['usuario'];
            $_SESSION['id_Usuario']=$resultado['id_Usuario'];
            //cargar permisos aplicación para el usuario
            require_once 'modelos/M_Menus.php';
            $objPer=new M_Menus();
            $_SESSION['permisos']=$objPer->getPermisosEnAplicacion($_SESSION['id_Usuario']);

            header('Location: index.php');
        }else{
            $msj= 'Datos erroneos.';
        }
    }
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <script src="librerias/jquery-3.5.1/jquery-3.5.1.js"></script>
    <link rel="stylesheet" 
        href="librerias/bootstrap-4.5.2-dist/css/bootstrap.min.css">
    <script src="librerias/bootstrap-4.5.2-dist/js/bootstrap.min.js">
        </script>
    <link rel="stylesheet" href="css/index.css">
    <link rel="stylesheet" href="css/login.css">
    <script src="pwa_BD.js"></script>
    <script  type="text/javascript">
        function validar(){ //validando para reenviar form a la propia login.php y recargando php.
            $('.inputRed').removeClass('inputRed');
            $('#msj').html('');

            if( $('#usuario').val()=='' ){
                $('#usuario').addClass('inputRed');
            }
            if( $('#pass').val()=='' ){
                $('#pass').addClass('inputRed');
            }

            if( $('.inputRed').length>0){
                $('#msj').html('Debe rellenar los campos');
            }else{
                $('#formLogin').submit();
                
            }
        }


        function validarAjax(){ //validando por ajax para poder usar indexedDB.
            $('.inputRed').removeClass('inputRed');
            $('#msj').html('');

            if( $('#usuario').val()=='' ){
                $('#usuario').addClass('inputRed');
            }
            if( $('#pass').val()=='' ){
                $('#pass').addClass('inputRed');
            }

            if( $('.inputRed').length>0){
                $('#msj').html('Debe rellenar los campos');
            }else{
                var parametros='&controlador=Usuarios';
                parametros+='&metodo=loginUsuarioAjax';
                parametros+='&login='+$('#usuario').val()+'&pass='+$('#pass').val();
                $.ajax({
                    url:'C_Ajax.php',
                    type:'post',
                    data: parametros,
                    dataType:'json',
                    success: function(usu){
                        if(usu.permitido=='S'){
                            // es usuario correcto
                            //console.log('Usuario:'+usu.usuario+' id:'+usu.id_Usuario);

                            let objUsuario = new Object();
                            objUsuario.id_Usuario= usu.id_Usuario;
                            objUsuario.usuario= usu.usuario;
                            registrarUsuario(objUsuario);


                            $('#formLogin').attr('action', 'index.php');
                           // $('#formLogin').submit();
                        }else{
                            $('#msj').html('Datos erroneos.');
                        }
                    }
                })
            }
        }
        function no_iniciar(){
            $('#formLogin').attr('action', 'index.php');
            $('#formLogin').submit();
        }
    </script>
<body class="bodylogin">
    <div class="container-fluid">
        <div class="container">
            <div class="logo">
                <img src="imagenes/logo.png" style="height:6em;">
            </div>
        </div>
        <div class="row" style="text-align:center;">
            <div class="form-group col-lg-4 col-md-4 col-sm-3 col-sx-2"></div>
            <div class="form-group col-lg-4 col-md-4 col-sm-6 col-sx-8" style="text-align:center;">
                <div style="width:fit-content;text-align:left;margin:auto;">
                    <h1>Acceder..</h1>
                    <span id="msj" name="msj" style="color:red;font-size:1.3em;"><?php echo $msj;?></span>
                    <form id="formLogin" name="formLogin" 
                            class="" action="#" method="post">
                        <label for="usuario">Usuario<br>
                            <input class="form-control" 
                                id="usuario" name="usuario" 
                                type="text" size="50" value="<?php echo $usuario; ?>">
                        </label>
                        <br>
                        <br>
                        <label for="pass">Contraseña<br>
                            <input class="form-control" 
                                id="pass" name="pass" type="password" 
                                size="20" value="<?php echo $pass; ?>">
                        </label><br><br>
                        <button type="button" class="btn btn-success" onclick="validar();">Aceptar (recarga php)</button>
                        <button type="button" class="btn btn-success" onclick="validarAjax();">Aceptar (Ajax)</button>
                        <button type="button" class="btn btn-info" onclick="no_iniciar();">NO iniciar</button>
                    </form>
                </div>
            </div>  
            <div class="form-group col-lg-4 col-md-4 col-sm-3 col-sx-2"></div>  
        </div>    
    </div>
</body>
</html>