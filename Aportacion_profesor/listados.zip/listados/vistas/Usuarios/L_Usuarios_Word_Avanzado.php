<?php 
$usuarios=$datos['usuarios'];

header("Expires: Mon, 26 Jul 1997 05:00:00 GMT"); // Fecha pasada, para que caduque en el momento de abrirlo
header("Last-Modified: " . gmdate("D, d M Y H:i:s") . " GMT"); 
header("Cache-Control: no-store, no-cache, must-revalidate"); // HTTP/1.1
header("Cache-Control: post-check=0, pre-check=0", false);
header("Pragma: no-cache"); // HTTP/1.0

header('Content-Type: application/word');
header('Content-Disposition: attachment; filename=Usuarios_'.date('Ymd').'.doc');

function invertirFechaSinHora($fecha, $separador){
    if($fecha==''){
        return '';
    }else{
        list($c,$m,$b)=explode('-',str_replace('/','-',substr($fecha,0,10)));
        return $b.$separador.$m.$separador.$c;
    }
}


$html='<!DOCTYPE html  PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN"
 						"http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
		<html>
			<head>
				<meta http-equiv="Content-Type" content="text/HTML; charset=iso-8859-1"  />
                <xml>
                    <x:WordDocument>
                        <w:View>Print</w:View>
                    </x:WordDocument>
                </xml>
                <style type="text/css">
                    @page{
                        size:210mm 297mm;
                        margin: 30mm 15mm 10mm 25mm; /*top, right, bottom, left*/
                        mso-header: e1;
                        mso-header-margin: 14pt;
                        mso-footer: f1;
                        mso-footer-margin: 14pt;
                            
                    }
                    @page Section1{ }
                    div.Section1 { page:Section1; }

                    #e1{
                        margin: 0cm 0cm 0cm 30cm;
                    }
                    #f1{
                        margin: 0cm 0cm 0cm 30cm;
                    }
                    p.msoFooter{
						tab-stops:right 170mm;
					}

                    .saltoPagina {
                    	page-break-after: always;
                    }

                    #tablaUsuarios{
                        font-size:11pt;
                        font-family:"Times New Roman","serif";
                        border-collapse: collapse;
                        width:100%; 
                    }
                    #tablaUsuarios th{
                        font-size:12pt;
                        margin-left:5pt;
                        margin-right:5pt;
                        border-bottom: 2px solid black;
                    }
                    #tablaUsuarios td{
                        margin-left:5pt;
                        margin-right:5pt;
                    }
                </style>
            </head>
            <body>';

$html.='<div class="Section1">';

$html.='<table id="tablaUsuarios" border="0" style="width:99%">';
$html.=  '<thead>';
$html.=     '<tr>';
$html.=         '<th style="text-align:right;width:1%">ID</th>';
$html.=         '<th style="text-align:left;width:1%;">Login</th>';
$html.=         '<th style="text-align:left;width:auto;">Usuario</th>';
$html.=         '<th style="text-align:left;width:auto;">Mail</th>';
$html.=         '<th style="text-align:center;width:1%;">Fecha Alta</th>';
$html.=         '<th style="text-align:center;width:1%;">Activo</th>';
$html.=     '</tr>';
$html.=  '</thead>';

$impar=true;

foreach ($usuarios as $reg){
    if($impar){
        $estilo='';
        $impar=false;
    }else{
        $estilo='background-color:rgb(192,192,192);' ;
        $impar=true;
    }

    $html.=  '<tr>';
    $html.=     '<td style="text-align:right;'.$estilo.'">'.$reg['id_Usuario'].'</td>';
    $html.=     '<td style="text-align:left;'.$estilo.'">'.$reg['login'].'</td>';
    $html.=     '<td style="text-align:left;'.$estilo.'">'.$reg['apellido_1'].' '.$reg['apellido_2'].', '.$reg['nombre'].'</td>';
    $html.=     '<td style="text-align:left;'.$estilo.'">'.$reg['mail'].'</td>';
    $html.=     '<td style="text-align:center;'.$estilo.'">'.invertirFechaSinHora($reg['fecha_Alta'],'/').'</td>';
    $activo='';
    if($reg['activo']=='N') $activo='NO';
    $html.=     '<td style="text-align:center;'.$estilo.'">'.$activo.'</td>';
    $html.=  '</tr>';
}
$html.='</table>';

//$html.=json_encode($_SERVER);
//$html.= $_SERVER['HTTP_REFERER'].'<br>';
$ruta= substr($_SERVER['HTTP_REFERER'], 0, strripos($_SERVER['HTTP_REFERER'],'/'));
//$html.=$ruta;
$html.='</div>';//fin seccion1


$html.='
		<div style="mso-element:header" id="e1" name="e1">
            <table id="tablaHeader">
                <tr>
                    <td style="width:100mm;" id="tdTitulo">
                        Pedidos
                    </td>
                    <td style="width:70mm;" id="tdLogo">
                        <img id="logo" 
                            src="'.$ruta.'/imagenes/logo.png"  
                            height="40" width="60" align="right" />
                    </td>
                </tr>
            </table>
        </div>';
$html.='
		<div style="mso-element:footer" id="f1" name="f1">
            <p class="msoFooter">
                <span style="mso-tab-count:1">
                    <span style="mso-field-code:PAGE"></span> / <span style="mso-field-code:NUMPAGES"></span>
                </span>
            </p>                    
        </div>';

$html.=     '</body>
		</html>';
    
echo $html;  