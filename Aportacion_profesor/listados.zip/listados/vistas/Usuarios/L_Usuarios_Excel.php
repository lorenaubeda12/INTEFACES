<?php 

$usuarios=$datos['usuarios'];

header('Content-Type: application/excel');
header('Content-Disposition: attachment; filename=Usuarios_'.date('Ymd').'.xls');

function invertirFechaSinHora($fecha, $separador){
    if($fecha==''){
        return '';
    }else{
        list($c,$m,$b)=explode('-',str_replace('/','-',substr($fecha,0,10)));
        return $b.$separador.$m.$separador.$c;
    }
}



$html='<table id="tablaUsuarios" border="0" style="width:auto;">';
$html.=  '<thead>';
$html.=     '<tr>';
$html.=         '<th style="text-align:right;width:1%">ID</th>';
$html.=         '<th style="text-align:left;width:1%;">Login</th>';
$html.=         '<th style="text-align:left;width:auto;">Usuario</th>';
$html.=         '<th style="text-align:left;width:auto;">Mail</th>';
$html.=         '<th style="text-align:center;width:1%;">Fecha Alta</th>';
$html.=         '<th style="text-align:center;width:1%;">Activo</th>';
$html.=     '</tr>';
$html.=  '</thead>';

foreach ($usuarios as $reg){
    $html.=  '<tr>';
    $html.=     '<td style="text-align:right;">'.$reg['id_Usuario'].'</td>';
    $html.=     '<td style="text-align:left;">'.$reg['login'].'</td>';
    $html.=     '<td style="text-align:left;">'.$reg['apellido_1'].' '.$reg['apellido_2'].', '.$reg['nombre'].'</td>';
    $html.=     '<td style="text-align:left;">'.$reg['mail'].'</td>';
    $html.=     '<td style="text-align:center;">'.invertirFechaSinHora($reg['fecha_Alta'],'/').'</td>';
    $activo='';
    if($reg['activo']=='N') $activo='NO';
    $html.=     '<td style="text-align:center;">'.$activo.'</td>';
    $html.=  '</tr>';
}
$html.='</table>';

    
echo $html;  