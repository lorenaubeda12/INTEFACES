<?php 

$usuarios=$datos['usuarios'];

header('Content-Type: application/word');
header('Content-Disposition: attachment; filename=Usuarios_'.date('Ymd').'.doc');

function invertirFechaSinHora($fecha, $separador){
    if($fecha==''){
        return '';
    }else{
        list($c,$m,$b)=explode('-',str_replace('/','-',substr($fecha,0,10)));
        return $b.$separador.$m.$separador.$c;
    }
}


$html='<!DOCTYPE html  PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN"
 						"http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
		<html>
            <head>
                <style type="text/css">
                    table {  border-collapse: collapse; }
                    td {border: 1px solid black; padding: 5px;}

                    
                </style>
            </head>
            <body>';

$htmlet.='<table id="tablaUsuarios" border="0" style="width:99%">';
$htmlet.=  '<thead>';
$htmlet.=     '<tr>';
$htmlet.=         '<th style="text-align:right;width:1%">ID</th>';
$htmlet.=         '<th style="text-align:left;width:1%;">Login</th>';
$htmlet.=         '<th style="text-align:left;width:auto;">Usuario</th>';
$htmlet.=         '<th style="text-align:left;width:auto;">Mail</th>';
$htmlet.=         '<th style="text-align:center;width:1%;">Fecha Alta</th>';
$htmlet.=         '<th style="text-align:center;width:1%;">Activo</th>';
$htmlet.=     '</tr>';
$htmlet.=  '</thead>';

$html.=$htmlet; //encabezado tabla 1a pagina
$impar=true;
$fila=0;

foreach ($usuarios as $reg){
    // if($fila>25){
    //     $html.= '</table>';
    //     $html.= '<br clear="all" class="saltoPagina" />'; //salto de pagina
    //     $html.=$htmlet; //encabezado tabla pag siguiente
    //     $fila=1;
    // }else{
    // }
    $fila++;

    if($impar){
        $estilo='';
        $impar=false;
    }else{
        $estilo='background-color:rgb(192,192,192);' ;
        $impar=true;
    }

    $html.=  '<tr>';
    $html.=     '<td style="text-align:right;'.$estilo.'">'.$reg['id_Usuario'].'</td>';
    $html.=     '<td style="text-align:left;'.$estilo.'">'.$reg['login'].'</td>';
    $html.=     '<td style="text-align:left;'.$estilo.'">'.$reg['apellido_1'].' '.$reg['apellido_2'].', '.$reg['nombre'].'</td>';
    $html.=     '<td style="text-align:left;'.$estilo.'">'.$reg['mail'].'</td>';
    $html.=     '<td style="text-align:center;'.$estilo.'">'.invertirFechaSinHora($reg['fecha_Alta'],'/').'</td>';
    $activo='';
    if($reg['activo']=='N') $activo='NO';
    $html.=     '<td style="text-align:center;'.$estilo.'">'.$activo.'</td>';
    $html.=  '</tr>';
}
$html.='</table>';


$html.=     '</body>
        </html>';
    
echo $html;  