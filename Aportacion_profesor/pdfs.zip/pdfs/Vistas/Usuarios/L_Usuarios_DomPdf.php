<?php 

$usuarios=$datos['usuarios'];

function invertirFechaSinHora($fecha, $separador){
    if($fecha==''){
        return '';
    }else{
        list($c,$m,$b)=explode('-',str_replace('/','-',substr($fecha,0,10)));
        return $b.$separador.$m.$separador.$c;
    }
}

$html='<!DOCTYPE html>
            <body>

            <style type="text/css">
                @page {
    				margin: 30mm 15mm 20mm 30mm; /* arriba dcha abajo izq */
    			}
                header {
    		    	position: fixed; left: 0mm; top: -25mm; right: 0mm; height: 22mm;
    			}
                footer {
    		    	position: fixed; left: 0px; bottom: -30mm; right: 0px;
    		    	height: 20mm; text-align:right;
    			}
                footer .pagenum:before {
                      content: counter(page, decimal) ; /* ya no soporta el contador de total paginas*/
                }
                table {
				    width:100%;
                }
            </style>';
            
$logo=base64_encode(file_get_contents('imagenes/logo.png'));
$html.='<header>
		<table>
			<tr>
				<td style="width:auto;text-align:left;" nowrap>Listado de usuarios.</td>
				<td style="width:1%;text-align:right;">
					<img src="data:image/png;base64, '.$logo.'" style="height:15mm;" />
				</td>
			</tr>
		</table>
	</header>
    <footer>    
        <div class="pagenum-container">Página <span class="pagenum"></span></div>
   </footer>';

$html.='<table id="tablaUsuarios" border="0" style="width:auto;">';
$html.=  '<thead>';
$html.=     '<tr>';
$html.=         '<th style="text-align:right;width:1%">ID</th>';
$html.=         '<th style="text-align:left;width:1%;">Login</th>';
$html.=         '<th style="text-align:left;width:auto;">Usuario</th>';
$html.=         '<th style="text-align:left;width:auto;">Mail</th>';
$html.=         '<th style="text-align:center;width:1%;">Fecha Alta</th>';
$html.=         '<th style="text-align:center;width:1%;">Activo</th>';
$html.=     '</tr>';
$html.=  '</thead>';

foreach ($usuarios as $reg){
    $html.=  '<tr>';
    $html.=     '<td style="text-align:right;">'.$reg['id_Usuario'].'</td>';
    $html.=     '<td style="text-align:left;">'.$reg['login'].'</td>';
    $html.=     '<td style="text-align:left;">'.$reg['apellido_1'].' '.$reg['apellido_2'].', '.$reg['nombre'].'</td>';
    $html.=     '<td style="text-align:left;">'.$reg['mail'].'</td>';
    $html.=     '<td style="text-align:center;">'.invertirFechaSinHora($reg['fecha_Alta'],'/').'</td>';
    $activo='';
    if($reg['activo']=='N') $activo='NO';
    $html.=     '<td style="text-align:center;">'.$activo.'</td>';
    $html.=  '</tr>';
}
$html.='</table>';

    
//echo $html; 
require 'librerias/dompdf_2-0-3/autoload.inc.php';
use Dompdf\Dompdf;
$dompdf = new Dompdf();
$dompdf->loadHtml($html);
$dompdf->setPaper('A4', 'portail');
$dompdf->render();
$dompdf->stream();