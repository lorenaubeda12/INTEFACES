<?php  //Documentación en:  http://www.fpdf.org/
require('librerias/fpdf185/fpdf.php');

class PDF extends FPDF{
// Cabecera de página
    function Header(){
        $this->SetFont('Arial','BI',16);
        $this->Cell(80);
        $this->Cell(30,10,'Listado de usuarios',0,0,'C');
        $this->Image('imagenes/logo.png',180,8,25);//img,x,y,w,h,type,link
        $this->Ln(20);//salto línea(y+alto último Cell)
    }

    // Pie de página
    function Footer(){
        $this->SetY(-15); //distancia margen inferior
        $this->SetFont('Arial','',8);
        $this->Cell(190,10,utf8_decode('Página ').$this->PageNo().'/{nb}',0,0,'R');
    }
}


function invertirFechaSinHora($fecha, $separador){
    if($fecha==''){
        return '';
    }else{
        list($c,$m,$b)=explode('-',str_replace('/','-',substr($fecha,0,10)));
        return $b.$separador.$m.$separador.$c;
    }
}

function cabeceraTabla($pdf){
    //encabezado de la tabla
    $y=$pdf->GetY(); $ySuperior=$y;
    $pdf->SetFont('Arial','B',12);
    $pdf->SetXY(15, $y);
    $pdf->MultiCell(10,10,'ID','B','c', false);
    $pdf->SetXY(25,$y);
    $pdf->MultiCell(25,10,'Login','B','L', false);
    $pdf->SetXY(50,$y);
    $pdf->MultiCell(55,10,'Usuario','B','L', false);
    $pdf->SetXY(105,$y);
    $pdf->MultiCell(50,10,'Mail','B','L', false);
    $pdf->SetXY(155,$y);
    $pdf->MultiCell(25,10,'Fecha Alta','B','c', false);
    $pdf->SetXY(180,$y);
    $pdf->MultiCell(20,10,'Activo','B','C', false);
}


// Creación del objeto de la clase heredada
$pdf = new PDF();
$pdf->AliasNbPages();
$pdf->AddPage();


$usuarios=$datos['usuarios'];

//pintar cabecera de tabla
cabeceraTabla($pdf);
$pdf->SetFont('Times','',12);
$impar=true;
$alto=10;
$pdf->SetFillColor(200,220,255); //para sombrear las celdas
foreach ($usuarios as $reg){
    $y=$pdf->GetY();
    if($y>265){
        $pdf->AddPage();
        //pintar cabecera de tabla
        cabeceraTabla($pdf);
        $pdf->SetFont('Times','',12);
        $y=$pdf->GetY();
        $impar=true;
    }

    if($impar){
        $fondo='1';
    }else{
        $fondo='0';
    }
    $impar=!$impar;

    $pdf->SetXY(15, $y);
    $pdf->MultiCell(10,$alto,$reg['id_Usuario'],0,'c', $fondo);
    $pdf->SetXY(25,$y);
    $pdf->MultiCell(25,$alto,$reg['login'],0,'L', $fondo);
    $pdf->SetXY(50,$y);
    $nombre=$reg['apellido_1'].' '.$reg['apellido_2'].', '.$reg['nombre'];
    $pdf->MultiCell(55,$alto,$nombre,0,'L', $fondo);
    $pdf->SetXY(105,$y);
    $pdf->MultiCell(50,$alto,$reg['mail'],0,'L', $fondo);
    $pdf->SetXY(155,$y);
    $pdf->MultiCell(25,$alto,invertirFechaSinHora($reg['fecha_Alta'],'/'),0,'c', $fondo);
    $activo='SI';
    if($reg['activo']=='N') {
        $activo='NO';
    }
    $pdf->SetXY(180,$y);
    $pdf->MultiCell(20,$alto,$activo,0,'C', $fondo);
}

//for($i=1;$i<=40;$i++)
//    $pdf->MultiCell(0,10,'Imprimiendo línea número '.$i,0,1);
$pdf->Output('D', 'Listado Usuarios.pdf', true);
?>